import { CartItemPipe } from './cart-item.pipe';

describe('CartItemPipe', () => {
  it('create an instance', () => {
    const pipe = new CartItemPipe();
    expect(pipe).toBeTruthy();
  });
});

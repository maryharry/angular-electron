import { Component } from '@angular/core';
import { ElectronService } from './core/services';
import { TranslateService } from '@ngx-translate/core';
import { CommonService } from './services/common.service';
import { Router, NavigationEnd, Event } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(
    private electronService: ElectronService,
    private translate: TranslateService,
    public router: Router,
    public commonService: CommonService
    ) {
      this.commonService.setTitle('Dynamic Title : POS SYSTEM');

      this.translate.setDefaultLang('en');
  }
  title = 'angular-electron';
}

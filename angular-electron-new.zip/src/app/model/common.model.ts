export interface cartProduct {
    id: number;
    productName: string;
    categoryName: string;
    price: number;
    productimages: any[];
    quantityPerUnit: number;
    quantity: number;
    totalAmount:number;
    status:string;
    color:string;
}
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import {AuthGuardService} from '../services/auth-guard.service';
import { CommonService } from '../services/common.service';
import * as jQuery from 'jquery';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm:FormGroup;

  constructor(
    private router: Router,
    private formbuilder:FormBuilder,
    private authService:AuthGuardService,
    private commonService:CommonService
    ) { 
      this.createForm();
      this.commonService.setTitle("POS | Login");
    }

  ngOnInit(): void {
    if(this.authService.gettoken) {
      this.router.navigateByUrl("/home");
    }
    console.log('LoginComponent');
    (function ($) {
      $(document).ready(function(){
        console.log("Hello from jQuery!");
        $('body').css("background-color",'red');
      });
    });
  }

  createForm() {
    this.loginForm = this.formbuilder.group({
      email: ['', Validators.required],
      password:['',Validators.required]
   });
   console.log(this.loginForm)
  }

  SubmitLoginForm() {
    if (this.loginForm.valid) {
      console.log(this.loginForm);
      console.log('form submitted');
      localStorage.setItem("SeesionUser",this.loginForm.value.email);
      
      this.router.navigateByUrl("/home");
    } else {
      // validate all form fields
    }
  }

}
